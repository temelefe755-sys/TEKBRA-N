# Production Export

AppDeploy App ID: `onebrain-yg8wcw`
Snapshot version: `1787152066738`
Live URL: `https://onebrain-yg8wcw.v2.appdeploy.ai/`
Export date: `2026-08-19`

Bu klasör GitHub'a yüklemek için hazırlanmıştır.
Hiçbir gerçek secret, API anahtarı, kullanıcı mesajı, şifre veya ödeme tokenı export edilmemiştir.
