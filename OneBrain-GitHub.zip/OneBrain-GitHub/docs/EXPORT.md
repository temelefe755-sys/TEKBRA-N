# OneBrain GitHub Export

- AppDeploy App ID: `onebrain-yg8wcw`
- Kaynak alınan sürüm: `1787150539913`
- Tarih: 19 Ağustos 2026
- Gerçek API anahtarları: **Dahil edilmedi**
- OAuth client secret değerleri: **Dahil edilmedi**
- Kullanıcı sohbet/veritabanı içeriği: **Dahil edilmedi**

Bu paket GitHub sürüm kontrolü ve geliştirme için hazırlanmıştır. Mevcut üretim uygulaması AppDeploy SDK bağımlılıkları kullanır.
