# OneBrain

Personal AI OS projesinin GitHub kaynak arşivi.

Canlı sürüm: https://onebrain-yg8wcw.v2.appdeploy.ai/

## Snapshot
- AppDeploy app id: `onebrain-yg8wcw`
- Snapshot: `1787150539913`
- Export: 2026-08-19
- Gerçek API/OAuth secret değerleri: **dahil edilmedi**

## Ana özellikler
- AI sohbeti, sohbet geçmişi ve seçici hafıza
- Dosya çalışma alanı
- Otomasyonlar ve push bildirim
- AI sağlayıcı bağlantıları
- OAuth altyapısı
- Şifre kasası ve ödeme kural taslakları
- Kullanım merkezi
- Görsel/video/müzik/ses stüdyosu
- PWA
- Güvenlik merkezi

## Önemli
Bu kaynak AppDeploy üzerinde çalışacak şekilde yazılmıştır. Frontend `@appdeploy/client`, backend `@appdeploy/sdk` kullanır. GitHub'a koymak sürüm kontrolü ve geliştirme için uygundur; AppDeploy dışındaki bir hostta bağımsız çalıştırmak için bu servis katmanlarının taşınması gerekir.

## Sonraki işler
- Google Workspace gerçek OAuth kurulumu
- Gmail/Outlook/Calendar günlük dijital özet entegrasyonu
- Sağlayıcı resmi API anahtarı sayfalarına tek tık yönlendirme
- Gerçek provider router ve kota/fatura adaptörleri
- Desktop/Device Agent
