# OneBrain

OneBrain, kişisel yapay zeka işletim sistemi projesidir.

## Canlı uygulama
https://onebrain-yg8wcw.v2.appdeploy.ai/

## Bu paket hangi sürüm?
- AppDeploy App ID: `onebrain-yg8wcw`
- Canlı snapshot: `1787152066738`
- Export tarihi: `2026-08-19`
- Gerçek API anahtarları / OAuth secret değerleri: **Dahil edilmedi**
- Kullanıcı sohbetleri / şifreler / ödeme tokenları: **Dahil edilmedi**

## Güncel özellikler
- AI sohbeti ve sol menü sohbet geçmişi
- Seçici uzun süreli hafıza
- Dosya/fotoğraf ekleme ve güvenli workspace
- Doğal dille otomasyonlar ve bildirimler
- Sesli asistan
- Görsel üretimi
- fal.ai ile video, müzik ve ses → müzik akışı
- OpenAI, Claude, Gemini, Grok, Mistral, Cohere, DeepSeek, Perplexity, OpenRouter, Groq, Together AI ve fal.ai bağlantı merkezi
- `Bağla` → sağlayıcının resmî API/hesap sayfası → anahtar oluştur → `Panodan al` → şifreli kaydet akışı
- Google Workspace / Microsoft / GitHub / Slack OAuth altyapısı
- Şifre kasası
- Tokenlaştırılmış ödeme kasası ve otomatik ödeme kural taslakları
- AI kullanım merkezi ve yerel limitler
- PWA / iPhone ve masaüstü uygulama kurulumu
- Güvenlik merkezi

## AppDeploy bağımlılığı
Canlı sürüm frontend tarafında `@appdeploy/client`, backend tarafında `@appdeploy/sdk` kullanır. Bu repo sürüm kontrolü için uygundur. Başka bir sağlayıcıda bağımsız çalıştırmak için auth, DB, storage, notifications, cron ve AI katmanlarını standart servislerle değiştirmek gerekir.

## Güvenlik
`.env`, API key, OAuth client secret, token, parola ve kullanıcı verilerini GitHub'a commit etmeyin.
